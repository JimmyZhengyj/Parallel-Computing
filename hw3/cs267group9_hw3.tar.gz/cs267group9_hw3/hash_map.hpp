#pragma once

#include "kmer_t.hpp"
#include <upcxx/upcxx.hpp>
#include "butil.hpp"

struct HashMap {
    std::vector <upcxx::global_ptr<kmer_pair>> data;
    std::vector <upcxx::global_ptr<int>> used;

    size_t global_size;
    size_t local_size;

    HashMap(size_t global_size);

    // Keep track of locations in memory
    size_t offset;
    int num_ranks;
    int rank;

    // Most important functions: insert and retrieve
    // k-mers from the hash table.
    bool insert(const kmer_pair& kmer);
    bool find(const pkmer_t& key_kmer, kmer_pair& val_kmer);

    // Helper functions

    // Read to a logical data slot in the table.
    upcxx::global_ptr<kmer_pair> read_slot_data(uint64_t slot);
    upcxx::global_ptr<int> read_slot_used(uint64_t slot);

    // Check if slot is already used.
    bool slot_used(uint64_t slot);

    // Move to next slot
    void next_slot(uint64_t* global_slot);

    // atomic domain for shared ints
    upcxx::atomic_domain<int> ad_int = upcxx::atomic_domain<int>({upcxx::atomic_op::compare_exchange,upcxx::atomic_op::load});
};

HashMap::HashMap(size_t size) {
    global_size = size;

    num_ranks = upcxx::rank_n();
    rank = upcxx::rank_me();

    // Divide up work evenly
    
    offset = (global_size - 1) / num_ranks + 1;
    local_size = offset;
    // add remainder to last rank
    if (rank == num_ranks - 1) {
        local_size = global_size - (num_ranks - 1) * offset; 
    }

    // Local and shared data structures
    data = std::vector<upcxx::global_ptr<kmer_pair>>(num_ranks);
    used = std::vector<upcxx::global_ptr<int>>(num_ranks);
    upcxx::global_ptr<kmer_pair> local_data = upcxx::new_array<kmer_pair>(local_size);
    upcxx::global_ptr<int> local_used = upcxx::new_array<int>(local_size);
    upcxx::future<upcxx::global_ptr<kmer_pair>> * fut_data = new upcxx::future<upcxx::global_ptr<kmer_pair>>[num_ranks];
    upcxx::future<upcxx::global_ptr<int>> * fut_used = new upcxx::future<upcxx::global_ptr<int>>[num_ranks];

    // Broadcasting pointers to shared memory
    for (int i = 0; i < num_ranks; i++) {
        fut_data[i] = upcxx::broadcast(local_data, i);
        fut_used[i] = upcxx::broadcast(local_used, i);
    }
    
    // Accumulate data; block on communication
    for (int i = 0; i < num_ranks; i++) {
        data[i] = fut_data[i].wait();
        used[i] = fut_used[i].wait();
    }
}

bool HashMap::insert(const kmer_pair& kmer) {

    // Find starting position
    uint64_t hash = kmer.hash();
    uint64_t slot = hash % global_size;
    uint64_t probe = slot;

    // Find correct slot
    int exchanged = ad_int.compare_exchange(read_slot_used(slot),0, 1, std::memory_order_relaxed).wait();
    while (exchanged != 0) {
        next_slot(&slot);
        if (probe == slot)
            return false;
        exchanged = ad_int.compare_exchange(read_slot_used(slot),0, 1, std::memory_order_relaxed).wait();
    }
    upcxx::rput(kmer, read_slot_data(slot)).wait();
    return true;
}

bool HashMap::find(const pkmer_t& key_kmer, kmer_pair& val_kmer) {
    uint64_t hash = key_kmer.hash();
    uint64_t slot = hash % global_size;
    uint64_t probe = slot;
    do {
        if (slot_used(slot)) break;
        kmer_pair my_kmer = upcxx::rget(read_slot_data(slot)).wait();
        if (my_kmer.kmer == key_kmer) {
            val_kmer = my_kmer;
            return true;
        }
        next_slot(&slot);
    } while (slot != probe);
    return false;
}

bool HashMap::slot_used(uint64_t slot) { 
    return ad_int.load(read_slot_used(slot), std::memory_order_relaxed).wait() == 0;
}

upcxx::global_ptr<kmer_pair> HashMap::read_slot_data(uint64_t slot) { 
    return data[slot/offset]+(slot%offset); 
}

upcxx::global_ptr<int> HashMap::read_slot_used(uint64_t slot) { 
    return used[slot/offset]+(slot%offset); 
}

void HashMap::next_slot(uint64_t* global_slot) {
    *global_slot = (*global_slot + 1) % global_size;
}